<?php

namespace App\Http\Controllers;

use App\Models\Avaliacao;
use Illuminate\Http\Request;

class AvaliacaoController extends Controller
{
    public function index()
    {
        return Avaliacao::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'nota' => 'required|integer|min:0|max:10',
            'usuario_id' => 'required|exists:usuarios,id',
            'postagem_id' => 'required|exists:postagens,id',
        ]);

        $avaliacao = Avaliacao::create($request->all());

        return response()->json($avaliacao, 201);
    }

    public function show($id)
    {
        $avaliacao = Avaliacao::findOrFail($id);
        return response()->json($avaliacao);
    }

    public function update(Request $request, $id)
    {
        $avaliacao = Avaliacao::findOrFail($id);

        $avaliacao->update($request->only(['nota']));

        return response()->json($avaliacao);
    }

    public function destroy($id)
    {
        $avaliacao = Avaliacao::findOrFail($id);
        $avaliacao->delete();

        return response()->json(['message' => 'Avaliação deletada com sucesso.']);
    }
}
