<?php

namespace App\Http\Controllers;

use App\Models\Postagem;
use Illuminate\Http\Request;

class PostagemController extends Controller
{
    public function index()
    {
        return Postagem::all();
    }

    public function store(Request $request)
    {
        $request->validate([
            'titulo' => 'required|string|max:255',
            'descricao' => 'nullable|string',
            'imagem1' => 'nullable|url',
            'imagem2' => 'nullable|url',
            'imagem3' => 'nullable|url',
            'video' => 'nullable|url',
            'musica' => 'nullable|url',
            'usuario_id' => 'required|exists:usuarios,id',
        ]);

        $postagem = Postagem::create($request->all());

        return response()->json($postagem, 201);
    }

    public function show($id)
    {
        $postagem = Postagem::findOrFail($id);
        return response()->json($postagem);
    }

    public function update(Request $request, $id)
    {
        $postagem = Postagem::findOrFail($id);

        $postagem->update($request->all());

        return response()->json($postagem);
    }

    public function destroy($id)
    {
        $postagem = Postagem::findOrFail($id);
        $postagem->delete();

        return response()->json(['message' => 'Postagem deletada com sucesso.']);
    }
}
