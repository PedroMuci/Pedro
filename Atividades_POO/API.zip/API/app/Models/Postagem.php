<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Postagem extends Model
{
    use HasFactory;

    // Corrige o nome da tabela
    protected $table = 'postagens';

    protected $fillable = [
        'titulo',
        'descricao',
        'imagem_1',
        'imagem_2',
        'imagem_3',
        'musica',
        'video',
        'user_id',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function avaliacoes()
    {
        return $this->hasMany(Avaliacao::class);
    }

    public function comentarios()
    {
        return $this->hasMany(Comentario::class);
    }
}
