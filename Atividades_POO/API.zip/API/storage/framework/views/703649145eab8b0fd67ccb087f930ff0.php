<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Trabalho POO</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background-color: #f5f5f5;
        }
        nav a {
            margin-right: 15px;
            text-decoration: none;
            color: #333;
        }
        nav {
            margin-bottom: 20px;
        }
        h1 {
            color: #444;
        }
        ul {
            list-style-type: none;
            padding-left: 0;
        }
        li {
            margin-bottom: 10px;
        }
        a.button {
            padding: 5px 10px;
            background-color: #3490dc;
            color: white;
            border-radius: 4px;
            text-decoration: none;
        }
        a.button:hover {
            background-color: #2779bd;
        }
    </style>
</head>
<body>

    <nav>
        <a href="<?php echo e(route('menu')); ?>">Menu</a>
        <a href="<?php echo e(route('usuarios.index')); ?>">Usuários</a>
        <a href="<?php echo e(route('postagens.index')); ?>">Postagens</a>
        <a href="<?php echo e(route('avaliacoes.index')); ?>">Avaliações</a>
        <a href="<?php echo e(route('comentarios.index')); ?>">Comentários</a>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\Pedro\Atividades_POO\API\resources\views/layouts/app.blade.php ENDPATH**/ ?>