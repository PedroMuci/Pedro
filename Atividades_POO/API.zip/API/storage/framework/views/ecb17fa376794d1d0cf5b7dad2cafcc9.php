

<?php $__env->startSection('content'); ?>
    <h1>Menu Principal</h1>

    <ul>
        <li><a href="<?php echo e(route('usuarios.index')); ?>">Gerenciar Usuários</a></li>
        <li><a href="<?php echo e(route('postagens.index')); ?>">Gerenciar Postagens</a></li>
        <li><a href="<?php echo e(route('avaliacoes.index')); ?>">Gerenciar Avaliações</a></li>
        <li><a href="<?php echo e(route('comentarios.index')); ?>">Gerenciar Comentários</a></li>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Pedro\Atividades_POO\API\resources\views/menu.blade.php ENDPATH**/ ?>