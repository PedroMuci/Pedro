@extends('layouts.app')

@section('content')
    <h1>Menu Principal</h1>

    <ul>
        <li><a href="{{ route('usuarios.index') }}">Gerenciar Usuários</a></li>
        <li><a href="{{ route('postagens.index') }}">Gerenciar Postagens</a></li>
        <li><a href="{{ route('avaliacoes.index') }}">Gerenciar Avaliações</a></li>
        <li><a href="{{ route('comentarios.index') }}">Gerenciar Comentários</a></li>
    </ul>
@endsection
