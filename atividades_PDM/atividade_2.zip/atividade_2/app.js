function toggleMenu() {
  document.getElementById("menu").classList.toggle("active");
}