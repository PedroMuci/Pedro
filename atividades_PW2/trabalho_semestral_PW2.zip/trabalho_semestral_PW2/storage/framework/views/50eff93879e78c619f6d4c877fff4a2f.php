

<?php $__env->startSection('title', 'Nova Postagem'); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width:600px; margin:50px auto;">
    <h2 style="text-align:center; margin-bottom:30px;">Criar Nova Postagem</h2>

    <?php if($errors->any()): ?>
        <div style="background:#FFCDD2; padding:10px; margin-bottom:20px; border-radius:6px;">
            <ul style="margin:0; padding-left:20px;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('gerenciar.store')); ?>">
        <?php echo csrf_field(); ?>

        <input type="text" name="titulo" placeholder="Título" value="<?php echo e(old('titulo')); ?>" required>

        <textarea name="texto" placeholder="Conteúdo" required style="height:150px;"><?php echo e(old('texto')); ?></textarea>

        <input type="url" name="imagem1" placeholder="URL da Imagem 1 (obrigatório)" value="<?php echo e(old('imagem1')); ?>" required>
        <input type="url" name="imagem2" placeholder="URL da Imagem 2 (opcional)" value="<?php echo e(old('imagem2')); ?>">
        <input type="url" name="imagem3" placeholder="URL da Imagem 3 (opcional)" value="<?php echo e(old('imagem3')); ?>">

        <input type="url" name="video" placeholder="URL do Vídeo (opcional)" value="<?php echo e(old('video')); ?>">
        <input type="url" name="musica" placeholder="URL da Música (opcional)" value="<?php echo e(old('musica')); ?>">

        <input type="text" name="fonte" placeholder="Fonte (obrigatório)" value="<?php echo e(old('fonte')); ?>" required>

        <input type="text" name="palavra_chave1" placeholder="Palavra-chave 1" value="<?php echo e(old('palavra_chave1')); ?>">
        <input type="text" name="palavra_chave2" placeholder="Palavra-chave 2" value="<?php echo e(old('palavra_chave2')); ?>">
        <input type="text" name="palavra_chave3" placeholder="Palavra-chave 3" value="<?php echo e(old('palavra_chave3')); ?>">

        <button type="submit" class="btn-acao" style="width:100%; margin-top:20px;">
            Publicar
        </button>
    </form>
    <div style="text-align:center; margin-top:30px;">
        <a href="<?php echo e(route('gerenciar.index')); ?>" class="btn-acao" style="
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 999;"
        >
            ← Voltar
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Pedro\atividades_PW2\trabalho_semestral_PW2\resources\views/gerenciar/create.blade.php ENDPATH**/ ?>