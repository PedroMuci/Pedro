

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width: 800px; width: 100%; background-color: white; border-radius: 12px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); padding: 40px 30px;">

    <h2 style="text-align: center; font-size: 28px; color: #3E2723; margin-bottom: 10px;">Dashboard</h2>
    <p style="text-align: center; font-style: italic; color: #5f3c2b; margin-bottom: 30px;">
        Total de Usuários: <?php echo e($countUsers); ?> | Postagens: <?php echo e($countPosts); ?> | Avaliações: <?php echo e($countReviews); ?>

    </p>

    
    <div style="border: 1px solid #A33617; border-radius: 10px; padding: 20px; background-color: #fff1ec; margin-bottom: 30px;">
        <form method="POST" action="<?php echo e(route('admin.dashboard.deleteAllUsuarios')); ?>" style="margin-bottom: 15px;">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <input type="submit" value="Excluir TODOS os Usuários" class="btn-acao" style="width: 100%;">
        </form>

        <form method="POST" action="<?php echo e(route('admin.dashboard.deleteAllPostagens')); ?>" style="margin-bottom: 15px;">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <input type="submit" value="Excluir TODAS as Postagens" class="btn-acao" style="width: 100%;">
        </form>

        <form method="POST" action="<?php echo e(route('admin.dashboard.deleteAllAvaliacoes')); ?>">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <input type="submit" value="Excluir TODAS as Avaliações" class="btn-acao" style="width: 100%;">
        </form>
    </div>

    
    <div style="margin-bottom: 30px;">
        <h3 style="font-size: 20px; color: #3E2723; margin-bottom: 10px;">Usuários</h3>
        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div style="display: flex; justify-content: space-between; align-items: flex-start; padding: 12px; border: 1px solid #ccc; border-radius: 8px; margin-bottom: 10px;">
                <span style="max-width: 75%; word-wrap: break-word;">
                    <?php echo e($user->nome); ?> (<?php echo e($user->email); ?>)
                </span>
                <form method="POST" action="<?php echo e(route('admin.dashboard.deleteUsuario', $user->id)); ?>">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <input type="submit" value="Remover" class="btn-acao" style="padding: 8px 12px; font-size: 0.9em;">
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p style="color: #666;">Nenhum usuário encontrado.</p>
        <?php endif; ?>
    </div>

    
    <div style="margin-bottom: 30px;">
        <h3 style="font-size: 20px; color: #3E2723; margin-bottom: 10px;">Postagens</h3>
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div style="display: flex; justify-content: space-between; align-items: flex-start; padding: 12px; border: 1px solid #ccc; border-radius: 8px; margin-bottom: 10px;">
                <span style="max-width: 75%; word-wrap: break-word;">
                    <?php echo e($post->titulo); ?>

                </span>
                <form method="POST" action="<?php echo e(route('admin.dashboard.deletePostagem', $post->id)); ?>">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <input type="submit" value="Remover" class="btn-acao" style="padding: 8px 12px; font-size: 0.9em;">
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p style="color: #666;">Nenhuma postagem encontrada.</p>
        <?php endif; ?>
    </div>

    
    <div style="margin-bottom: 30px;">
        <h3 style="font-size: 20px; color: #3E2723; margin-bottom: 10px;">Avaliações</h3>
        <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div style="display: flex; justify-content: space-between; align-items: flex-start; padding: 12px; border: 1px solid #ccc; border-radius: 8px; margin-bottom: 10px;">
                <span style="max-width: 75%; word-wrap: break-word;">
                    <?php echo e($review->comentario); ?> (Nota: <?php echo e($review->nota); ?>)
                </span>
                <form method="POST" action="<?php echo e(route('admin.dashboard.deleteAvaliacao', $review->id)); ?>">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <input type="submit" value="Remover" class="btn-acao" style="padding: 8px 12px; font-size: 0.9em;">
                </form>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p style="color: #666;">Nenhuma avaliação encontrada.</p>
        <?php endif; ?>
    </div>

    
    <div style="text-align:center; margin-top:30px;">
        <a href="<?php echo e(route('admin.index')); ?>" class="btn-acao" style="
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 999;"
        >
            ← Voltar
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Pedro\atividades_PW2\trabalho_semestral_PW2\resources\views/dashboard/index.blade.php ENDPATH**/ ?>