

<?php $__env->startSection('title', 'Gerenciar Postagens'); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width:800px; margin:40px auto;">
 
    <h2 style="
        font-size:2.8em;
        margin-bottom:20px;
        text-align:center;
        color:#4E342E;
    ">Gerenciar Postagens</h2>

   
    <div style="text-align:center; margin-bottom:30px;">
        <a href="<?php echo e(route('gerenciar.create')); ?>"
           class="btn-acao"
           style="width:200px; font-size:1.1em;">
            Nova Postagem
        </a>
    </div>

 
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="
            background: #FFFFFF;
            border: 2px solid #A33617;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 30px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.05);
        ">
           
            <h3 style="
                margin-top: 0;
                font-size:2em;
                color:#3E2723;
            ">
                <?php echo e($post->titulo); ?>

            </h3>

          
            <p style="
                color:#5D4037;
                line-height:1.6;
                margin-bottom:25px;
                max-height:4.8em;
                overflow:hidden;
            ">
                <?php echo e(\Illuminate\Support\Str::limit($post->texto, 120, '...')); ?>

            </p>

            
            <div style="display:flex; justify-content: space-between;">
             
                <a href="<?php echo e(route('gerenciar.edit', $post->id)); ?>"
                   class="btn-acao"
                   style="width:120px; font-size:1em;">
                    Editar
                </a>

             
                <form method="POST"
                      action="<?php echo e(route('gerenciar.destroy', $post->id)); ?>"
                      onsubmit="return confirm('Deseja realmente excluir esta postagem?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit"
                            class="btn-acao"
                            style="width:120px; font-size:1em;">
                        Excluir
                    </button>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($posts->isEmpty()): ?>
        <p style="
            text-align:center;
            color:#8D6E63;
            margin-top:50px;
            font-size:1.2em;
        ">
            Você ainda não tem postagens. Clique em “Nova Postagem” para começar!
        </p>
    <?php endif; ?>
    <div style="text-align:center; margin-top:30px;">
        <a href="<?php echo e(route('menu')); ?>" class="btn-acao" style="
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 999;"
        >
            ← Voltar
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Pedro\atividades_PW2\trabalho_semestral_PW2\resources\views/gerenciar/index.blade.php ENDPATH**/ ?>