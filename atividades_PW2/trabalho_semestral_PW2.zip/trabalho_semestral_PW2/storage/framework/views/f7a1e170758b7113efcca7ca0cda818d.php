

<?php $__env->startSection('content'); ?>
    <style>
        main {
            align-items: flex-start !important;
            justify-content: flex-start !important;
        }
        .historia-header {
            width: 100%;
            max-width: 1000px;
            margin: 20px auto 120px;
            padding: 40px;
            background: #FAF9F5;
            position: relative;
            z-index: 1;
        }
        .historia-grid {
            width:100%;
            max-width:1000px;
            margin:0 auto 60px;
            display: flex;
            flex-wrap: wrap;
            gap:30px;
            justify-content: center;
            align-items: stretch;
            z-index: 0;
        }
        .historia-card {
            width:280px;
            background:#FFFFFF;
            border:2px solid #A33617;
            border-radius:12px;
            overflow:hidden;
            box-shadow:0 4px 8px rgba(0,0,0,0.1);
            display:flex;
            flex-direction:column;
        }
        .historia-card img {
            width:100%; height:100%; object-fit:cover;
        }
        .historia-card-content {
            flex:1;
            padding:15px;
            display:flex;
            flex-direction:column;
        }
        .historia-nota {
            text-align:center;
            padding:8px;
            background:#FFF5F0;
            border-bottom:1px solid #A33617;
        }
    </style>

    
    <header class="historia-header">
        <h1 style="
            font-family: serif;
            font-size: 3em;
            color: #3E2723;
            text-align: center;
            margin: 0 0 15px;
        ">Histórias Perdidas</h1>

        <form method="GET" action="<?php echo e(route('historias.index')); ?>" style="text-align:center;">
            <input
                type="text"
                name="busca"
                placeholder="Pesquisar..."
                value="<?php echo e(request('busca')); ?>"
                style="
                    width: 60%;
                    max-width: 400px;
                    padding: 12px 16px;
                    font-size: 1em;
                    border: 2px solid #A33617;
                    border-radius: 20px;
                    box-sizing: border-box;
                "
            >
        </form>
    </header>

    <?php if($posts->isEmpty()): ?>
        <div style="
            width:100%;
            min-height:60vh;
            display:flex;
            align-items:center;
            justify-content:center;
        ">
            <p style="color:#8D6E63; font-size:1.2em;">
                Nenhuma história encontrada.
            </p>
        </div>
    <?php else: ?>
        <div class="historia-grid">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $media = $post->avaliacoes->avg('nota');
                ?>

                <div class="historia-card">
                    
                    <div class="historia-nota">
                        <?php if(is_null($media)): ?>
                            <strong style="color:#A33617;">N/A</strong>
                        <?php else: ?>
                            <strong style="color:#A33617;"><?php echo e(round($media, 1)); ?> / 10</strong>
                        <?php endif; ?>
                    </div>


                    <?php if($post->imagem1): ?>
                        <div style="flex:0 0 150px; overflow:hidden;">
                            <img
                                src="<?php echo e(asset($post->imagem1)); ?>"
                                onerror="this.src='https://via.placeholder.com/300x180?text=Imagem+Indispon%C3%ADvel'"
                                alt="<?php echo e($post->titulo); ?>"
                            >
                        </div>
                    <?php endif; ?>

                    <div class="historia-card-content">
                        
                        <h3 style="
                            font-size:1.2em;
                            margin:0 0 10px;
                            color:#3E2723;
                        "><?php echo e(\Illuminate\Support\Str::limit($post->titulo, 40)); ?></h3>

                        <p style="
                            font-size:0.95em;
                            color:#5D4037;
                            line-height:1.4;
                            margin:0 0 15px;
                            flex:1;
                        ">
                            <?php echo e(\Illuminate\Support\Str::limit($post->texto, 80, '...')); ?>

                        </p>

                        
                        <button
                            type="button"
                            class="btn-acao"
                            style="margin-top:auto;"
                            onclick="location.href='<?php echo e(route('historias.show', $post->id)); ?>'"
                        >
                            Ler Mais
                        </button>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    
    <div style="text-align:center; margin-top:30px;">
        <a href="<?php echo e(route('menu')); ?>" class="btn-acao" style="
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 999;
        ">
            ← Voltar
        </a>
    </div>


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.historia-card');
            let maxH = 0;
            cards.forEach(c => {
                const h = c.offsetHeight;
                if (h > maxH) maxH = h;
            });
            cards.forEach(c => c.style.height = maxH + 'px');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Pedro\atividades_PW2\trabalho_semestral_PW2\resources\views/historias/index.blade.php ENDPATH**/ ?>