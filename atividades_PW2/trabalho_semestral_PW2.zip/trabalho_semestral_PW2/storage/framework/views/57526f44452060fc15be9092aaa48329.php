

<?php $__env->startSection('content'); ?>
<div style="width:320px; margin:50px auto;">
    <h2>Cadastro</h2>

    <?php if($errors->any()): ?>
        <div style="color: red; margin-bottom: 15px;">
            <ul style="padding-left: 20px;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>
        <div style="margin-bottom:15px;">
            <input type="text" name="name" placeholder="Nome" value="<?php echo e(old('name')); ?>" required style="width:100%; padding:8px;">
        </div>
        <div style="margin-bottom:15px;">
            <input type="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" required style="width:100%; padding:8px;">
        </div>
        <div style="margin-bottom:15px;">
            <input type="password" name="password" placeholder="Senha" required style="width:100%; padding:8px;">
        </div>
        <div style="margin-bottom:15px;">
            <input type="password" name="password_confirmation" placeholder="Confirme a senha" required style="width:100%; padding:8px;">
        </div>
        <div style="margin-bottom:15px;">
            <input type="date" name="data_nascimento" placeholder="Data de Nascimento" value="<?php echo e(old('data_nascimento')); ?>" style="width:100%; padding:8px;">
        </div>
        <button class="btn-acao" style="width:100%;">Cadastrar</button>
    </form>

    <div style="text-align:center; margin-top:30px;">
        <a href="<?php echo e(route('login')); ?>" class="btn-acao" style="
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 999;">
            ← Voltar
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Pedro\atividades_PW2\trabalho_semestral_PW2\resources\views/auth/register.blade.php ENDPATH**/ ?>