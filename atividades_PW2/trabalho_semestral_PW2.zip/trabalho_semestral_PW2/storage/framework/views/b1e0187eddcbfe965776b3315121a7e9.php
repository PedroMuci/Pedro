

<?php $__env->startSection('title', 'Histórias Perdidas'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Histórias Perdidas</h1>
    <p class="subtitle">
        Um site dedicado a compartilhar histórias interessantes
        e importantes que foram esquecidas ou ignoradas.
    </p>

    <div class="menu-buttons">
        <a href="<?php echo e(route('historias.index')); ?>" class="btn-acao">Histórias</a>
        <a href="<?php echo e(route('gerenciar.index')); ?>" class="btn-acao">Gerenciar Postagens</a>
        <a href="<?php echo e(route('admin.index')); ?>" class="btn-acao">Administração</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Pedro\atividades_PW2\trabalho_semestral_PW2\resources\views/menu.blade.php ENDPATH**/ ?>