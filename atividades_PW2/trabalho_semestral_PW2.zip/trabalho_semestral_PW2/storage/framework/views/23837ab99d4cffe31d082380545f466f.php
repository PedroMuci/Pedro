

<?php $__env->startSection('title', 'Meu Perfil'); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width:400px; margin:50px auto; text-align:center;">
    <h2 style="color:#3E2723; margin-bottom:10px;">Olá, <?php echo e($user->name); ?></h2>
    <p style="color:#5D4037; margin-bottom:20px;">
        <strong>Tipo de conta:</strong> <?php echo e(ucfirst($user->tipo_conta)); ?>

    </p>

    <?php if($pendente): ?>
        <p style="color: #A33617; margin-bottom:20px;">Solicitação de admin pendente</p>
    <?php endif; ?>

    <div class="menu-buttons" style="width:100%; margin-top:30px; display:flex; flex-direction:column; gap:12px; align-items:center;">
        <a href="<?php echo e(route('perfil.edit')); ?>" class="btn-acao" style="width: 200px;">Editar Perfil</a>

        <?php if($user->tipo_conta !== 'criador'): ?>
            <form method="POST" action="<?php echo e(route('perfil.solicitar.criador')); ?>" style="margin:0; width: 200px;">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn-acao" style="width: 100%;">Solicitar Criador</button>
            </form>
        <?php endif; ?>

        <?php if($user->tipo_conta !== 'admin' && !$pendente): ?>
            <form method="POST" action="<?php echo e(route('perfil.solicitar.admin')); ?>" style="margin:0; width: 200px;">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn-acao" style="width: 100%;">Solicitar Admin</button>
            </form>
        <?php endif; ?>

        
        <form method="POST" action="<?php echo e(route('logout')); ?>" style="margin:0; width: 200px;">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn-acao" style="width: 100%;">Sair</button>
        </form>
    </div>
    <div style="text-align:center; margin-top:30px;">
        <a href="<?php echo e(route('menu')); ?>" class="btn-acao" style="
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 999;"
        >
            ← Voltar
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Pedro\atividades_PW2\trabalho_semestral_PW2\resources\views/perfil/index.blade.php ENDPATH**/ ?>