

<?php $__env->startSection('title', 'Editar Perfil'); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width:400px; margin:50px auto;">
    <h2 style="text-align:center;">Editar Perfil</h2>

    <?php if(session('mensagem')): ?>
        <div style="background:#C8E6C9; padding:10px; margin-bottom:15px;">
            <?php echo e(session('mensagem')); ?>

        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('perfil.update')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" placeholder="Nome" required>
        <input type="date" name="data_nascimento" value="<?php echo e(old('data_nascimento', $user->data_nascimento)); ?>">

            <button type="submit" class="btn-acao" style="width: 100%;">Salvar Alterações</button>
    </form>
    <div style="text-align:center; margin-top:30px;">
        <a href="<?php echo e(route('perfil')); ?>" class="btn-acao" style="
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 999;"
        >
            ← Voltar
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Pedro\atividades_PW2\trabalho_semestral_PW2\resources\views/perfil/edit.blade.php ENDPATH**/ ?>