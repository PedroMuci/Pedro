

<?php $__env->startSection('bg-url', 'https://i.imgur.com/ZYYKS4c.png'); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width:800px; margin:30px auto;">

    <div style="
        background: rgba(255,255,255,0.9);
        border: 2px solid #A33617;
        border-radius:12px;
        padding:30px;
        box-shadow:0 4px 8px rgba(0,0,0,0.1);
        max-height: 80vh;
        overflow-y: auto;
    ">
        <h2 style="
            font-family: serif;
            font-size:2.5em;
            color:#3E2723;
            margin-bottom:10px;
            text-align: center;
            border-bottom:2px solid #A33617;
            padding-bottom:10px;
            word-break: break-word;
            overflow-wrap: break-word;
        ">
            <?php echo e($post->titulo); ?>

        </h2>

        <p style="
            font-size:1.1em;
            line-height:1.6;
            color:#5D4037;
            margin-bottom:20px;
            text-align:justify;
            word-break: break-word;
            overflow-wrap: break-word;
        ">
            <?php echo e($post->texto); ?>

        </p>

        <?php $__currentLoopData = ['imagem1','imagem2','imagem3']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($post->$img): ?>
                <div style="margin:20px 0; text-align:center;">
                    <img src="<?php echo e(asset($post->$img)); ?>"
                         alt="Imagem da postagem"
                         onerror="this.src='https://via.placeholder.com/600x300?text=Sem+Imagem'"
                         style="
                            max-width:100%;
                            border:2px solid #A33617;
                            border-radius:6px;
                            display:block;
                            margin: 0 auto;
                        ">
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($post->video): ?>
    <?php
        preg_match('/(?:v=|youtu\.be\/)([^&\?]+)/', $post->video, $v);
        $videoId = $v[1] ?? null;
    ?>

        <?php if($videoId): ?>
            <div style="margin:20px 0; text-align:center;">
                <iframe 
                    width="100%" 
                    height="315" 
                    src="https://www.youtube.com/embed/<?php echo e($videoId); ?>" 
                    frameborder="0" 
                    allowfullscreen
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    style="border:2px solid #A33617; border-radius:6px; display:block; margin:0 auto;">
                </iframe>
            </div>
            <?php else: ?>
                <p style="text-align:center; color:#A33617;">
                    Não foi possível carregar o vídeo.
                </p>
            <?php endif; ?>
        <?php endif; ?>


        <?php if($post->musica): ?>
            <div style="
                margin:20px 0;
                padding:15px;
                border:2px solid #A33617;
                border-radius:6px;
                background: #fafafa;
            ">
                <?php if(\Illuminate\Support\Str::contains($post->musica, 'open.spotify.com')): ?>
                    <iframe
                        src="<?php echo e(str_replace('track/','embed/track/',$post->musica)); ?>"
                        width="100%" height="80" frameborder="0"
                        allow="encrypted-media"
                        style="border:0; border-radius:6px;">
                    </iframe>

                <?php elseif(
                    \Illuminate\Support\Str::contains($post->musica, 'youtube.com') ||
                    \Illuminate\Support\Str::contains($post->musica, 'youtu.be') ||
                    \Illuminate\Support\Str::contains($post->musica, 'music.youtube.com')
                ): ?>
                    <?php
                        preg_match('/(?:v=|youtu\.be\/)([^&\?]+)/', $post->musica, $m);
                        $videoId = $m[1] ?? null;
                    ?>
                    <?php if($videoId): ?>
                        <iframe
                            width="100%" height="315"
                            src="https://www.youtube.com/embed/<?php echo e($videoId); ?>"
                            frameborder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowfullscreen
                            style="border:0; border-radius:6px;">
                        </iframe>
                    <?php else: ?>
                        <p style="text-align:center; color:#A33617;">
                            Não foi possível carregar o player de música.
                        </p>
                    <?php endif; ?>

                <?php else: ?>
                    <audio controls src="<?php echo e($post->musica); ?>" style="width:100%;"></audio>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div style="margin:20px 0; font-size:0.95em; color:#5D4037;">
            <p><strong>Fonte:</strong> <?php echo e($post->fonte); ?></p>
            <p><strong>Palavras-chave:</strong> <?php echo e($post->palavra_chave1); ?> <?php echo e($post->palavra_chave2); ?> <?php echo e($post->palavra_chave3); ?></p>
        </div>

        <?php if(auth()->guard()->check()): ?>
        <form method="POST" action="<?php echo e(route('avaliacoes.store', $post->id)); ?>" style="
            display:flex;
            align-items:center;
            gap:15px;
            margin:30px 0 0;
        ">
            <?php echo csrf_field(); ?>
            <label for="nota" style="
                font-weight:bold;
                color:#3E2723;
            ">Nota:</label>
            <input 
                type="number" 
                id="nota" 
                name="nota" 
                min="0" max="10" required
                style="
                    width:80px;
                    padding:8px;
                    font-size:1em;
                    border:2px solid #A33617;
                    border-radius:6px;
                "
            >
            <button type="submit" class="btn-acao" style="padding:10px 20px; font-size:1em;">
                Avaliar
            </button>
        </form>
        <?php endif; ?>
    </div>

    <div style="text-align:center; margin-top:30px;">
        <a href="<?php echo e(route('historias.index')); ?>" class="btn-acao" style="
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 999;
        ">
            ← Voltar
        </a>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Pedro\atividades_PW2\trabalho_semestral_PW2\resources\views/historias/show.blade.php ENDPATH**/ ?>