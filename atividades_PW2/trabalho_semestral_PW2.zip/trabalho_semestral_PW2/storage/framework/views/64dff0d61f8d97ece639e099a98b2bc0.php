

<?php $__env->startSection('title', 'Administração'); ?>

<?php $__env->startSection('content'); ?>
<style>
    .admin-container {
        max-width: 900px;
        margin: 40px auto;
        background: #fffefc;
        border: 1px solid #e0e0e0;
        border-radius: 10px;
        padding: 30px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    .section-title {
        margin-bottom: 15px;
        border-bottom: 2px solid #b54c26;
        padding-bottom: 5px;
        color: #6e2e15;
    }
    .card {
        background: #fffaf5;
        border: 1px solid #e3d5ca;
        padding: 15px;
        margin-bottom: 20px;
        border-radius: 8px;
        display: flex;
        flex-direction: column;
    }
    .card h4 {
        margin: 0 0 10px;
        color: #3e2723;
    }
    .card .actions {
        display: flex;
        justify-content: space-between;
        gap: 10px;
        margin-top: 10px;
    }
    .empty-box {
        padding: 20px;
        text-align: center;
        background: #fdf6f0;
        border: 1px dashed #e0c3aa;
        border-radius: 8px;
        color: #a0693d;
        font-style: italic;
    }
    .btn-acao {
        flex: 1;
        padding: 8px 0;
        background: #b54c26;
        border: 1px solid #b54c26;
        color: white;
        border-radius: 5px;
        text-align: center;
        cursor: pointer;
        transition: opacity 0.2s;
    }
    .btn-acao:hover {
        opacity: 0.9;
    }
</style>

<div class="admin-container">
    <h2 class="section-title">Administração</h2>

    
    <h3 class="section-title">Postagens Pendentes</h3>
    <?php if($posts->isEmpty()): ?>
        <div class="empty-box">
            Nenhuma postagem pendente no momento.
        </div>
    <?php else: ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <h4><?php echo e($post->titulo); ?></h4>
                <div class="actions">
                    
                    <form method="POST" action="<?php echo e(route('admin.aprovarPostagem', $post->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn-acao">Aprovar</button>
                    </form>
                    
                    <a href="<?php echo e(route('admin.editarPostagem', $post->id)); ?>" class="btn-acao">Editar</a>
                    
                    <form method="POST" action="<?php echo e(route('admin.excluirPostagem', $post->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn-acao">Excluir</button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    
    <h3 class="section-title" style="margin-top:40px;">Solicitações de Admin</h3>
    <?php if($solicitacoes->isEmpty()): ?>
        <div class="empty-box">
            Nenhuma solicitação de administrador no momento.
        </div>
    <?php else: ?>
        <?php $__currentLoopData = $solicitacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <p><strong><?php echo e($s->user->name); ?></strong> solicitou acesso de administrador.</p>
                <div class="actions">
                    
                    <form method="POST" action="<?php echo e(route('admin.aprovarSolicitacao', $s->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn-acao">Aprovar</button>
                    </form>
                    
                    <form method="POST" action="<?php echo e(route('admin.negarSolicitacao', $s->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn-acao">Negar</button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <div style="text-align:center; margin-top:30px;">
        <a href="<?php echo e(route('menu')); ?>" class="btn-acao" style="
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 999;"
        >
            ← Voltar
        </a>
    </div>
    
<div style="text-align:center; margin-top:30px;">
    <a href="<?php echo e(route('dashboard.index')); ?>" class="btn-acao">
        Acessar Dashboard
    </a>
</div>

<div style="text-align:center; margin-top:30px;">
    <a href="<?php echo e(route('menu')); ?>" class="btn-acao" style="
        position: fixed;
        top: 20px;
        left: 20px;
        z-index: 999;">
        ← Voltar
    </a>
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Pedro\atividades_PW2\trabalho_semestral_PW2\resources\views/admin/index.blade.php ENDPATH**/ ?>