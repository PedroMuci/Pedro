

<?php $__env->startSection('title', 'Editar Postagem'); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width:600px; margin:30px auto;">
    <h2 style="text-align:center; margin-bottom:30px;">Editar Postagem</h2>

    <?php if($errors->any()): ?>
        <div style="background:#FFCDD2; padding:10px; margin-bottom:20px; border-radius:6px;">
            <ul style="margin:0; padding-left:20px;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('gerenciar.update', $post->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <input type="text" name="titulo" value="<?php echo e(old('titulo', $post->titulo)); ?>" placeholder="Título" required>

        <textarea name="texto" placeholder="Conteúdo" required style="height:150px;"><?php echo e(old('texto', $post->texto)); ?></textarea>

        <input type="url" name="imagem1" value="<?php echo e(old('imagem1', $post->imagem1)); ?>" placeholder="URL da Imagem 1 (obrigatório)" required>
        <input type="url" name="imagem2" value="<?php echo e(old('imagem2', $post->imagem2)); ?>" placeholder="URL da Imagem 2 (opcional)">
        <input type="url" name="imagem3" value="<?php echo e(old('imagem3', $post->imagem3)); ?>" placeholder="URL da Imagem 3 (opcional)">

        <input type="url" name="video" value="<?php echo e(old('video', $post->video)); ?>" placeholder="URL do Vídeo (opcional)">
        <input type="url" name="musica" value="<?php echo e(old('musica', $post->musica)); ?>" placeholder="URL da Música (opcional)">

        <input type="text" name="fonte" value="<?php echo e(old('fonte', $post->fonte)); ?>" placeholder="Fonte (obrigatório)" required>

        <input type="text" name="palavra_chave1" value="<?php echo e(old('palavra_chave1', $post->palavra_chave1)); ?>" placeholder="Palavra-chave 1">
        <input type="text" name="palavra_chave2" value="<?php echo e(old('palavra_chave2', $post->palavra_chave2)); ?>" placeholder="Palavra-chave 2">
        <input type="text" name="palavra_chave3" value="<?php echo e(old('palavra_chave3', $post->palavra_chave3)); ?>" placeholder="Palavra-chave 3">

        <button type="submit" class="btn-acao" style="width:100%; margin-top:20px;">
            Salvar Alterações
        </button>
    </form>
    <div style="text-align:center; margin-top:30px;">
        <a href="<?php echo e(route('gerenciar.index')); ?>" class="btn-acao" style="
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 999;"
        >
            ← Voltar
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Pedro\atividades_PW2\trabalho_semestral_PW2\resources\views/gerenciar/edit.blade.php ENDPATH**/ ?>