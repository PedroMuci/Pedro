

<?php $__env->startSection('content'); ?>
<div style="width:320px; margin:80px auto; text-align:center;">
    <h2 style="margin-bottom:30px;">Login</h2>

    
    <?php if(session('erro_login')): ?>
        <div style="color: red; margin-bottom: 20px;">
            <?php echo e(session('erro_login')); ?>

        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <input type="email" name="email" placeholder="Email" required autofocus>
        <input type="password" name="password" placeholder="Senha" required>
        <button type="submit" class="btn-acao" style="width:100%; margin-top:20px;">
            Entrar
        </button>
    </form>

    <p style="margin-top:20px;">
        <a href="<?php echo e(route('register')); ?>" style="color:#5D3A2E; text-decoration:none;">Cadastrar-se</a>
    </p>
    <div style="text-align:center; margin-top:30px;">
        <a href="<?php echo e(route('menu')); ?>" class="btn-acao" style="
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 999;"
        >
            ← Voltar
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Pedro\atividades_PW2\trabalho_semestral_PW2\resources\views/auth/login.blade.php ENDPATH**/ ?>