

<?php $__env->startSection('title', 'Acesso Negado'); ?>

<?php $__env->startSection('content'); ?>
    <div style="text-align: center; margin-top: 100px;">
        <h1 style="font-size: 72px; color: #B71C1C;">403</h1>
        <h3 style="color: #D84315;">Você não tem permissão para acessar esta página.</h3>
        <a href="<?php echo e(route('menu')); ?>" class="btn-acao" style="margin-top: 20px;">Voltar ao Menu</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Pedro\atividades_PW2\trabalho_semestral_PW2\resources\views/errors/403.blade.php ENDPATH**/ ?>